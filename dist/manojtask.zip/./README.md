**************\*************** steps to run the ************\*\*\*\*************

1. please, install the respective modules NVM, Node using the below command
   nvm install 14
   nvm use 14

2. please install windows build tools
   npm install --global --production windows-build-tools

3. unzip the folder i have shared in the mail

4. Redirected to the folder and run
   npm install

5. And install the latestCLI freshdev
   npm install https://dl.freshdev.io/cli/fdk.tgz -g
   fdk version

6. Run fdk run

7. Go To the freshdesk url and go to the particular ticket

8. And enter ?dev=true in last of the url

9. And Click the above freshdesk icon and it's shows the modal with contact form
